/**
 * Author: Nardos Lemma
 * Course: CMSC 335
 * Date: 05/28/24
 * Description: This class models a Torus as a type of ThreeDimensionalShape. It holds
 * properties specific to a torus such as inner radius and outer radius.
 */
public class Torus extends ThreeDimensionalShape {
    private float innerRadius;
    private float outerRadius;

    public Torus(int numberOfDimension, float temporaryInner, float temporaryOuter) {
        super(numberOfDimension);
        this.innerRadius = temporaryInner;
        this.outerRadius = temporaryOuter;
    }

    public Torus(float tempInner, float tempOuter) {
        super();
        this.innerRadius = tempInner;
        this.outerRadius = tempOuter;
    }
    //setter for inner radius
    public void setInnerRadius(float tempInner) {
        this.innerRadius = tempInner;
    }
//getter for inner radius
    public float getInnerRadius() {
        return this.innerRadius;
    }
    //setter for outer radius
    public void setOuterRadius(float tempOuter) {
        this.outerRadius = tempOuter;
    }
    //getter for outer radius
    public float getOuterRadius() {
        return this.outerRadius;
    }
    //calculates the volume
    public double CalculateVolume() {
        return (2 * Math.pow(Math.PI, 2) * this.outerRadius * Math.pow(this.innerRadius, 2));
    }
}