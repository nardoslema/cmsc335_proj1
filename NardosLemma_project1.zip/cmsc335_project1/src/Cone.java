/**
 * Author:- Nardos Lemma
 * CMSC 335
 * 05| 28| 24
 * This class models a Cone as a type of ThreeDimensionalShape.
 * It holds properties specific to a cone such as radius and height
 */
public class Cone extends ThreeDimensionalShape {
    private float radius;
    private float height;

    public Cone(int numDim, float tempRadius, float tempHeight) {
        super(numDim);
        this.radius = tempRadius;
        this.height = tempHeight;
    }

    public Cone(float tempRadius, float tempHeight) {
        super();
        this.radius = tempRadius;
        this.height = tempHeight;
    }
    public void setHeight(float tempHeight) {
        this.height = tempHeight;
    }
    public void setRadius(float tempRadius) {
        this.radius = tempRadius;
    }

    public float getHeight() {
        return this.height;
    }

    public float getRadius() {
        return this.radius;
    }

    public double CalculateVolume() {
        return (Math.PI * Math.pow(this.radius, 2) * (this.height / 3));
    }
}