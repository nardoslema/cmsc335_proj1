/**
 Author: Nardos Lemma
 CMSC 335
 05/28/24
 This class represents a Rectangle, which is a type of TwoDimensionalShape.
 It holds properties specific to a rectangle such as its width and length.
 */

public class Rectangle extends TwoDimensionalShape {
    private float length;
    private float width;

    public Rectangle(int numDimension, float tempArea, float tempWidth, float tempL) {
        super(numDimension);
        this.length = tempL;
        this.width = tempWidth;
    }

    public Rectangle(float tempWi, float tempL) {
        super();
        this.length = tempL;
        this.width = tempWi;
    }

    // setter for length
    public void setLength(float tempLength) {
        this.length = tempLength;
    }

    // Getter for length
    public float getLength() {
        return this.length;
    }

    // setter for width
    public void setWidth(float tempWidth) {
        this.width = tempWidth;
    }
    // getter for width
    public float getWidth() {
        return this.width;
    }

    public double CalculateArea() {
        return this.width * this.length;
    }
}
