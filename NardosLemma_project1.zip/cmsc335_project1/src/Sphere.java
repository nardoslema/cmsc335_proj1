/**
 * Author: Nardos Lemma
 * Course: CMSC 335
 * Date: 05/28/24
 * Description: This class models a Sphere as a type of ThreeDimensionalShape. It holds
 * properties specific to a sphere such as radius.
 */
public class Sphere extends ThreeDimensionalShape{
    private float radius;

    public Sphere(int numDim, float tempRadius) {
        super(numDim);
        this.radius = tempRadius;
    }

    public Sphere(float tempRadius) {
        super();
        this.radius = tempRadius;
    }
//setter for radius
    public void setRadius(float tempRadius) {
        this.radius = tempRadius;
    }
//getter for radius
    public float getRadius() {
        return this.radius;
    }

    public double CalculateVolume() {
        return ((4 / 3)* Math.PI * Math.pow(this.radius, 3));
    }

}