/**
 * Author: Nardos Lemma
 * CMSC 335
 * 05/28/24
 * This class models a Circle as a type of TwoDimensionalShape.
 * It holds properties specific to a circle such as its radius and provides
 * methods to calculate the circle's area.
 */
public class Circle extends TwoDimensionalShape {
    private float radius;

    public Circle(int numDim, float rad) {
        super(numDim);
        this.radius = rad;
    }

    public Circle(float rad) {
        super();
        this.radius = rad;
    }

    public float getRadius() {
        return this.radius;
    }

    public void setRadius(float rad) {
        this.radius = rad;
    }

    public double CalculateArea() {
        return (Math.PI * Math.pow(this.radius, 2));
    }

}