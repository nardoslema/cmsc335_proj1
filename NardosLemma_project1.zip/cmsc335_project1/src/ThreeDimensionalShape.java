/**
 * Author: Nardos Lemma
 * Course: CMSC 335
 * Date: 05/28/24
 * Description: This class models a ThreeDimensionalShape as a type of Shape.
 */
public class ThreeDimensionalShape extends Shape {
    private float volume;

    //constructor
    public ThreeDimensionalShape(int nnumOfDimension) {
        super(nnumOfDimension);
        this.volume = 0;
    }

    public ThreeDimensionalShape() {
        super();
        this.volume = 0;
    }

    //setter
    public void setVolume(float tempVolume) {
        this.volume = tempVolume;
    }

    //getter
    public float getVolume() {
        return this.volume;
    }
}