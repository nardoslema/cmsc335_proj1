/**
 * Author: Nardos Lemma
 * CMSC 335
 * 05/28/24
 * This class serves as a menu-driven application to construct and calculate properties of various geometric shapes.
 * The user can select from a variety of shapes such as circles, rectangles, squares, triangles, spheres, cubes,
 * cones, cylinders, and torus.
 */
import java.util.Scanner;
import java.util.Date;

public class ShapeMenu {
    static Scanner input = new Scanner(System.in);

    private static void menuDisplay() {
        System.out.println("Select from the menu below:");
        System.out.println("1. Construct a Circle");
        System.out.println("2. Construct a Rectangle");
        System.out.println("3. Construct a Square");
        System.out.println("4. Construct a Triangle");
        System.out.println("5. Construct a Sphere");
        System.out.println("6. Construct a Cube");
        System.out.println("7. Construct a Cone");
        System.out.println("8. Construct a Cylinder");
        System.out.println("9. Construct a Torus");
        System.out.println("10. Exit the program");
    }
    // Method to ensure user inputs only valid positive numbers
    public static float Checker(/*float num*/) {
        float num;
        do{
            System.out.println("Enter a positive number");
            while(!input.hasNextFloat()) {
                System.out.println("Enter a number.");
                input.next();
            }
            num = input.nextFloat();
        }while(num <= 0);
        return num;
    }

    public static void main(String args[]) {
        int option;
        //Scanner input = new Scanner(System.in);
        System.out.println("**********Welcome to the Java OO Shapes Program **********");
        //Somehow, answering "Y" bypasses the loop
		/*System.out.println("Do you want to construct a shape?(Y or N)");
		String proceed = input.next();
		System.out.println(proceed);
		while(proceed == "Y") {*/
        menuDisplay();
        option = input.nextInt();
        while(option > 0 && option <= 10) {
            /* Initializing the common variables to 0s with each iteration */
            float radius = 0, outRadius = 0, height = 0, base = 0;
            float width = 0, length = 0;
            switch(option) {
                case 1:
                    System.out.println("You selected a Circle");
                    System.out.println("What is the radius of the circle?");
                    radius = Checker();
                    Circle tempC = new Circle(radius);
                    System.out.println("The area of the circle is "+ tempC.CalculateArea());
                    System.out.println();
                    break;
                case 2:
                    System.out.println("You have selected a Rectangle");
                    System.out.println("What is the length of the Rectangle?");
                    length = Checker();
                    System.out.println("What is the width of the Rectangle?");
                    width = Checker();
                    Rectangle tempR = new Rectangle(length,width);
                    System.out.println("The area of the Rectangle is "+ tempR.CalculateArea());
                    System.out.println();
                    break;
                case 3:
                    System.out.println("You have selected a Square");
                    System.out.println("What is the length of the Square?");
                    length = Checker();
                    Square tempS = new Square(length);
                    System.out.println("The area of the square is "+ tempS.CalculateArea());
                    System.out.println();
                    break;
                case 4:
                    System.out.println("You have selected a Triangle");
                    System.out.println("What is the height of the Triangle?");
                    height = Checker();
                    System.out.println("What is the base of the triangle?");
                    base = Checker();
                    Rectangle tempT = new Rectangle(base,height);
                    System.out.println("The area of the Triangle is "+ tempT.CalculateArea());
                    System.out.println();
                    break;
                case 5:
                    System.out.println("You have selected a Sphere");
                    System.out.println("What is the radius of the Sphere?");
                    radius = Checker();
                    Sphere tempSp = new Sphere(radius);
                    System.out.println("The area of the Sphere is "+ tempSp.CalculateVolume());
                    break;
                case 6:
                    System.out.println("You have selected a Cube");
                    System.out.println("What is the length of a side in the cube?");
                    length = Checker();
                    Cube tempCube = new Cube(length);
                    System.out.println("The area of the Cube is "+ tempCube.CalculateVolume());
                    System.out.println();
                    break;
                case 7:
                    System.out.println("You have selected a Cone");
                    System.out.println("What is the radius of the base of the cone?");
                    radius = Checker();
                    System.out.println("What is the height of the cone?");
                    height = Checker();
                    Cone tempCone = new Cone(radius,height);
                    System.out.println("The area of the Cone is "+ tempCone.CalculateVolume());
                    System.out.println();
                    break;
                case 8:
                    System.out.println("You have selected a Cylinder");
                    System.out.println("What is the radius of the base of the cylinder?");
                    radius = Checker();
                    System.out.println("What is the height of the cylinder?");
                    height = Checker();
                    Cylinder tempCylinder = new Cylinder(radius, height);
                    System.out.println("The area of the Cylinder is "+ tempCylinder.CalculateVolume());
                    System.out.println();
                    break;
                case 9:
                    System.out.println("You have selected a Torus");
                    System.out.println("What is the radius of the inner circle of the torus?");
                    radius = Checker();
                    System.out.println("What is the radius of the outer circle of the torus");
                    outRadius = Checker();
                    Torus tempTorus = new Torus(radius, outRadius);
                    System.out.println("The area of the Torus is "+ tempTorus.CalculateVolume());
                    System.out.println(tempTorus.getVolume());
                    System.out.println();
                    break;
                default:
                    System.out.println("Thank you for using the application. Today is"+ new Date());
                    System.exit(0);
            }

            System.out.println("Would you like to continue? (Y or N)");
            String proceed = input.next();

            while (!proceed.equalsIgnoreCase("Y") && !proceed.equalsIgnoreCase("N")) {
                System.out.println("Sorry, I do not understand. Enter Y or N");
                proceed = input.next();
            }

            if (proceed.equalsIgnoreCase("N")) {
                break;
            }
            menuDisplay();
            option = input.nextInt();
        }
        input.close();
        System.out.println("Thank you for using the application.");
    }
}