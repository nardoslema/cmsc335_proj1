/**
 * Author: Nardos Lemma
 * Course: CMSC 335
 * Date: 05/28/24
 * Description: This class serves as a superclass for all two-dimensional shapes.
 * It extends the Shape class and adds functionality to store and retrieve the area of a shape.
 */
public class TwoDimensionalShape extends Shape {
    private float area;

    public TwoDimensionalShape(int numOfDimension) {
        super(numOfDimension);
        this.area = 0;
    }

    public TwoDimensionalShape() {
        super();
        this.area = 0;
    }

    // setter for area
    public void setArea(float temporaryArea) {
        this.area = temporaryArea;
    }

    //getter for area
    public float getArea() {
        return this.area;
    }
}