/**
 * Author: Nardos Lemma
 * Course: CMSC 335
 * Date: 05/28/24
 * Description: This class models a Triangle as a type of TwoDimensionalShape. It holds
 * properties specific to a triangle such as base and height, and provides
 * methods to set and get the base and height, as well as calculate the triangle's area.
 */
public class Triangle extends TwoDimensionalShape {
    private float base;
    private float height;

    public Triangle(int numDim, float tempBase, float tempHeight) {
        super(numDim);
        this.base = tempBase;
        this.height = tempHeight;
    }

    public Triangle(float tempBase, float tempHeight) {
        super();
        this.base = tempBase;
        this.height = tempHeight;
    }

    public void setBase(float tempBase) {
        this.base = tempBase;
    }

    public void setHeight(float tempHeight) {
        this.height = tempHeight;
    }

    public float getBase() {
        return this.base;
    }

    public float getHeight() {
        return this.height;
    }

    public double CalculateArea() {
        return ((this.base / 2) * this.height);
    }
}