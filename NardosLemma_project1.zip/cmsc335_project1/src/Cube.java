/**
 * Author: Nardos Lemma
 * CMSC 335
 * 05/28/24
 * This class models a Cube as a type of ThreeDimensionalShape.
 */
public class Cube extends ThreeDimensionalShape {
    private float length;
    /**
     * Constructor to initialize a Cube with a specified number of dimensions and length.
     *
     * @param numDim The number of dimensions (should be 3 for a cube).
     * @param tempLength The length of the cube's side.
     */
    public Cube(int numDim, float tempLength) {
        super(numDim);
        this.length = tempLength;
    }

    public Cube(float tempLength) {
        super();
        this.length = tempLength;
    }
    public double CalculateVolume() {
        return Math.pow(this.length, 3);
    }
    public float getLength() {
        return this.length;
    }
    //Setter method for the length of the cube
    public void setLength(float tempLength) {
        this.length = tempLength;
    }

}
