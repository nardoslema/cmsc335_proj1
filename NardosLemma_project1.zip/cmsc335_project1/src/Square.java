/**
 * Author: Nardos Lemma
 * Course: CMSC 335
 * Date: 05/28/24
 * Description: This class models a Square as a type of TwoDimensionalShape. It holds
 * properties specific to a square such as length and provides a method to calculate
 * the square's area.
 */
public class Square extends TwoDimensionalShape {
    private float length;

    //constructor
    public Square(int numDim, float tempLength) {
        super(numDim);
        this.length = tempLength;
    }

    //constructor
    public Square(float tempLength) {
        super();
        this.length = tempLength;
    }

    public float getLength() {
        return this.length;
    }

    //setter for length
    public void setLength(float tempLength) {
        this.length = tempLength;
    }

    public double CalculateArea() {
        return Math.pow(this.length, 2);
    }
}