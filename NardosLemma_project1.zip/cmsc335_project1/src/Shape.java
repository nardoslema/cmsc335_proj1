/**
 * Author: Nardos Lemma
 * CMSC 335
 * 05/28/24
 * This class is my shape class
 */

public class Shape {
    private int numberOfDimensions;
    public Shape(int numOfDimension) {
        this.numberOfDimensions = numOfDimension;
    }

    public Shape() {
        this.numberOfDimensions = 0;
    }


    public void setNumDimension(int numDim) {
        this.numberOfDimensions = numDim;
    }

    public int getNumDimension() {
        return this.numberOfDimensions;
    }


}