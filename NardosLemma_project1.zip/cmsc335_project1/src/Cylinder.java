/**
 * Author: Nardos Lemma
 * CMSC 335
 * 05/28/24
 * This class models a Cylinder as a type of ThreeDimensionalShape. It holds
 * properties specific to a cylinder such as radius and height, and provides
 * methods to calculate the cylinder's area.
 */

public class Cylinder extends ThreeDimensionalShape {
    private float height;
    private float radius;

    public Cylinder(int numDim, float tempRadius, float tempHeight) {
        super(numDim);
        this.radius = tempRadius;
        this.height = tempHeight;
    }

    public Cylinder(float tempRadius, float tempHeight) {
        super();
        this.radius = tempRadius;
        this.height = tempHeight;
    }

    // setter method for the radius of the cylinder
    public void setRadius(float tempRadius) {
        this.radius = tempRadius;
    }

    // Getter method for the radius of the cylinder
    public float getRadius() {
        return this.radius;
    }

    // setter method for the height of the cylinder
    public void setHeight(float tempHeight) {
        this.height = tempHeight;
    }

    // Getter method for the height of the cylinder
    public float getHeight() {
        return this.height;
    }

    public double CalculateVolume() {
        return (Math.PI * Math.pow(this.radius, 2) * this.height);
    }

}